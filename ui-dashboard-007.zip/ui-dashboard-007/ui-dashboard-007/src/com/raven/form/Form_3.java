/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.raven.form;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;


/**
 *
 * @author romer
 */
public class Form_3 extends javax.swing.JPanel {

     private Connection con;
    private JTextArea jTextAreaCarpetas; // Para mostrar carpetas y avances

    public Form_3() {
        initComponents();
        setOpaque(false);
        jLabel2.setText("Subir Avance");
        conectar();       // Conexión a BD
        inicializarScroll();
        cargarAvances();  // Cargar avances existentes al iniciar
    }

    // ========================================
    // MÉTODO DE CONEXIÓN A LA BASE DE DATOS
    // ========================================
    private void conectar() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/promanage_ai", "root", ""
            );
            System.out.println("✅ Conectado a la base de datos");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error de conexión: " + e.getMessage());
        }
    }

    // ========================================
    // INICIALIZAR EL SCROLL PARA MOSTRAR DATOS
    // ========================================
    private void inicializarScroll() {
        jTextAreaCarpetas = new JTextArea();
        jTextAreaCarpetas.setEditable(false);
        jScrollPane1.setViewportView(jTextAreaCarpetas);
    }

    // ========================================
    // CARGAR AVANCES EXISTENTES DE LA BD
    // ========================================
    private void cargarAvances() {
        try {
            String sql = "SELECT id_equipo, descripcion, fecha FROM avances ORDER BY fecha DESC";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            jTextAreaCarpetas.setText(""); // Limpiar antes de cargar
            while (rs.next()) {
                int idEquipo = rs.getInt("id_equipo");
                String desc = rs.getString("descripcion");
                String fecha = rs.getString("fecha");
                jTextAreaCarpetas.append("📝 Equipo " + idEquipo + " | " + fecha + " -> " + desc + "\n");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar avances: " + e.getMessage());
        }
    }
    


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("sansserif", 1, 48)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(137, 137, 137));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Subir Avance ");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 330, -1));

        jButton1.setText("Guardar Avance");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 300, -1, -1));
        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 340, 430, 160));

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Numero de avance");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Proyecto/IDproyecto");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 110, 20));

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 200, 570, 30));

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane3.setViewportView(jTextArea2);

        jPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 90, 570, 30));

        jButton3.setText("Crea carpeta");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 300, -1, -1));

        jButton4.setText("Subir archivo");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 300, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 963, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 963, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 536, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 536, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            int idEquipo = Integer.parseInt(jTextArea1.getText().trim());
            String descripcion = jTextArea2.getText().trim();

            if (descripcion.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Escribe una descripción del avance.");
                return;
            }

            String sql = "INSERT INTO avances (id_equipo, descripcion, fecha) VALUES (?, ?, NOW())";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idEquipo);
            ps.setString(2, descripcion);
            ps.executeUpdate();

            // Mostrar inmediatamente en el scroll
            jTextAreaCarpetas.append("📝 Equipo " + idEquipo + " -> " + descripcion + "\n");

            JOptionPane.showMessageDialog(this, "✅ Avance guardado correctamente");

            jTextArea1.setText("");
            jTextArea2.setText("");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El ID del equipo debe ser un número válido.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al guardar avance: " + e.getMessage());
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
         String nombreProyecto = jTextArea1.getText().trim();
        if (nombreProyecto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Primero escribe el nombre del proyecto");
            return;
        }

        File carpeta = new File("C:/Proyectos/" + nombreProyecto);
        if (!carpeta.exists()) {
            if (carpeta.mkdirs()) {
                jTextAreaCarpetas.append("📂 Carpeta creada: " + carpeta.getAbsolutePath() + "\n");
                JOptionPane.showMessageDialog(this, "📂 Carpeta creada en: " + carpeta.getAbsolutePath());
            } else {
                jTextAreaCarpetas.append("❌ No se pudo crear la carpeta: " + nombreProyecto + "\n");
                JOptionPane.showMessageDialog(this, "❌ No se pudo crear la carpeta");
            }
        } else {
            jTextAreaCarpetas.append("⚠️ La carpeta ya existe: " + nombreProyecto + "\n");
            JOptionPane.showMessageDialog(this, "⚠️ La carpeta ya existe");
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        String nombreProyecto = jTextArea1.getText().trim();
    if (nombreProyecto.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Primero escribe el nombre del proyecto / ID de carpeta");
        return;
    }

    File carpeta = new File("C:/Proyectos/" + nombreProyecto);
    if (!carpeta.exists()) {
        JOptionPane.showMessageDialog(this, "La carpeta no existe. Crea la carpeta primero.");
        return;
    }

    // Abrir JFileChooser
    javax.swing.JFileChooser fc = new javax.swing.JFileChooser();
    int seleccion = fc.showOpenDialog(this);
    if (seleccion == javax.swing.JFileChooser.APPROVE_OPTION) {
        File archivoSeleccionado = fc.getSelectedFile();
        File destino = new File(carpeta, archivoSeleccionado.getName());

        try {
            java.nio.file.Files.copy(
                archivoSeleccionado.toPath(), 
                destino.toPath(),
                java.nio.file.StandardCopyOption.REPLACE_EXISTING
            );
            jTextAreaCarpetas.append("📁 Archivo subido: " + destino.getAbsolutePath() + "\n");
            JOptionPane.showMessageDialog(this, "Archivo subido correctamente.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al subir archivo: " + e.getMessage());
        }
    }
    }//GEN-LAST:event_jButton4ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    // End of variables declaration//GEN-END:variables
}
