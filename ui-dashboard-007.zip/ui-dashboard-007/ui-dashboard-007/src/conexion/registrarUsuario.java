/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

/**
 *
 * @author anali
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class registrarUsuario {
    
    public boolean registrarUsuario(String correo, String contraseña) {
        String sql = "INSERT INTO usuarios (correo, contraseña) VALUES (?, ?)";
        try (Connection con = conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, correo);
            ps.setString(2, contraseña); // ⚠️ en producción se recomienda encriptar
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("❌ Error al registrar: " + e.getMessage());
            return false;
        }
    }
}

