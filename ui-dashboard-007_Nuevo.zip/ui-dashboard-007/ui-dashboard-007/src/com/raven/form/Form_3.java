/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.raven.form;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;


/**
 *
 * @author romer
 */
public class Form_3 extends javax.swing.JPanel {

    private Connection con;
    private JTextArea jTextAreaCarpetas; // Para mostrar carpetas y avances

    public Form_3() {
        initComponents();
        setOpaque(false);
        jLabel2.setText("Subir Avance");
        conectar();       // Conexión a BD
        inicializarScroll();
        cargarAvances();  // Cargar avances existentes al iniciar
    }

    // ========================================
    // MÉTODO DE CONEXIÓN A LA BASE DE DATOS
    // ========================================
    private void conectar() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/promanage_ai", "root", ""
            );
            System.out.println("✅ Conectado a la base de datos");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error de conexión: " + e.getMessage());
        }
    }

    // ========================================
    // INICIALIZAR EL SCROLL PARA MOSTRAR DATOS
    // ========================================
    private void inicializarScroll() {
        jTextAreaCarpetas = new JTextArea();
        jTextAreaCarpetas.setEditable(false);
        jScrollPane1.setViewportView(jTextAreaCarpetas);
    }

    // ========================================
    // CARGAR AVANCES EXISTENTES DE LA BD
    // ========================================
    private void cargarAvances() {
        try {
            String sql = "SELECT id_equipo, descripcion, fecha FROM avances ORDER BY fecha DESC";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            jTextAreaCarpetas.setText(""); // Limpiar antes de cargar
            while (rs.next()) {
                int idEquipo = rs.getInt("id_equipo");
                String desc = rs.getString("descripcion");
                String fecha = rs.getString("fecha");
                jTextAreaCarpetas.append("📝 Equipo " + idEquipo + " | " + fecha + " -> " + desc + "\n");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar avances: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTextArea3 = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTextArea4 = new javax.swing.JTextArea();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTextArea5 = new javax.swing.JTextArea();
        jLabel6 = new javax.swing.JLabel();

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("sansserif", 1, 48)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(137, 137, 137));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Subir Avance ");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 330, -1));

        jButton1.setText("Guardar Avance");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 300, -1, -1));

        jScrollPane1.setBackground(new java.awt.Color(102, 102, 102));
        jScrollPane1.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 340, 430, 160));

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("ID proyecto");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, -1, -1));

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Nombre");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, 110, 20));

        jTextArea1.setBackground(new java.awt.Color(102, 102, 102));
        jTextArea1.setColumns(20);
        jTextArea1.setForeground(new java.awt.Color(255, 255, 255));
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 170, 570, 30));

        jTextArea2.setBackground(new java.awt.Color(102, 102, 102));
        jTextArea2.setColumns(20);
        jTextArea2.setForeground(new java.awt.Color(255, 255, 255));
        jTextArea2.setRows(5);
        jScrollPane3.setViewportView(jTextArea2);

        jPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 90, 570, 30));

        jButton3.setText("Crea carpeta");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 300, -1, -1));

        jButton4.setText("Subir archivo");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 300, -1, -1));

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Carpeta");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, 110, 20));

        jTextArea3.setBackground(new java.awt.Color(102, 102, 102));
        jTextArea3.setColumns(20);
        jTextArea3.setForeground(new java.awt.Color(255, 255, 255));
        jTextArea3.setRows(5);
        jScrollPane4.setViewportView(jTextArea3);

        jPanel1.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 210, 570, 30));

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Crea carpeta");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, 110, 20));

        jTextArea4.setBackground(new java.awt.Color(102, 102, 102));
        jTextArea4.setColumns(20);
        jTextArea4.setForeground(new java.awt.Color(255, 255, 255));
        jTextArea4.setRows(5);
        jScrollPane5.setViewportView(jTextArea4);

        jPanel1.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 250, 570, 30));

        jTextArea5.setBackground(new java.awt.Color(102, 102, 102));
        jTextArea5.setColumns(20);
        jTextArea5.setForeground(new java.awt.Color(255, 255, 255));
        jTextArea5.setRows(5);
        jScrollPane6.setViewportView(jTextArea5);

        jPanel1.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 130, 570, 30));

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("descripcion");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 110, 20));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 963, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 963, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 536, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 536, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            int idEquipo = Integer.parseInt(jTextArea1.getText().trim());
            String descripcion = jTextArea2.getText().trim();

            if (descripcion.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Escribe una descripción del avance.");
                return;
            }

            // Usar la misma carpeta que en el botón de subir archivo
            String nombreProyecto = jTextArea3.getText().trim();
            if (nombreProyecto.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Primero escribe el nombre de la carpeta o ID de carpeta.");
                return;
            }

            File carpeta = new File("C:/Proyectos/" + nombreProyecto);
            if (!carpeta.exists() || carpeta.listFiles() == null || carpeta.listFiles().length == 0) {
                JOptionPane.showMessageDialog(this, "❌ No puedes registrar el avance porque todavía no se ha subido ningún archivo a la carpeta del proyecto.");
                return; // sale antes de hacer el insert
            }

            // -------- Insertar avance --------
            String sql = "INSERT INTO avances (id_equipo, descripcion, fecha) VALUES (?, ?, NOW())";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idEquipo);
            ps.setString(2, descripcion);
            ps.executeUpdate();

            jTextAreaCarpetas.append("📝 Equipo " + idEquipo + " -> " + descripcion + "\n");
            JOptionPane.showMessageDialog(this, "✅ Avance guardado correctamente");

            jTextArea1.setText("");
            jTextArea2.setText("");

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El ID del equipo debe ser un número válido.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al guardar avance: " + e.getMessage());
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        String nombreProyecto = jTextArea4.getText().trim();
        if (nombreProyecto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Primero escribe el nombre del proyecto");
            return;
        }

        File carpeta = new File("C:/Proyectos/" + nombreProyecto);
        if (!carpeta.exists()) {
            if (carpeta.mkdirs()) {
                jTextAreaCarpetas.append("📂 Carpeta creada: " + carpeta.getAbsolutePath() + "\n");
                JOptionPane.showMessageDialog(this, "📂 Carpeta creada en: " + carpeta.getAbsolutePath());
            } else {
                jTextAreaCarpetas.append("❌ No se pudo crear la carpeta: " + nombreProyecto + "\n");
                JOptionPane.showMessageDialog(this, "❌ No se pudo crear la carpeta");
            }
        } else {
            jTextAreaCarpetas.append("⚠️ La carpeta ya existe: " + nombreProyecto + "\n");
            JOptionPane.showMessageDialog(this, "⚠️ La carpeta ya existe");
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        String nombreProyecto = jTextArea3.getText().trim();
        if (nombreProyecto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Primero escribe el nombre de la carpeta o ID de carpeta");
            return;
        }

        File carpeta = new File("C:/Proyectos/" + nombreProyecto);
        if (!carpeta.exists()) {
            JOptionPane.showMessageDialog(this, "La carpeta no existe. Crea la carpeta primero.");
            return;
        }

        // Abrir JFileChooser
        javax.swing.JFileChooser fc = new javax.swing.JFileChooser();
        int seleccion = fc.showOpenDialog(this);
        if (seleccion == javax.swing.JFileChooser.APPROVE_OPTION) {
            File archivoSeleccionado = fc.getSelectedFile();
            File destino = new File(carpeta, archivoSeleccionado.getName());

            try {
                java.nio.file.Files.copy(
                        archivoSeleccionado.toPath(),
                        destino.toPath(),
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING
                );
                jTextAreaCarpetas.append("📁 Archivo subido: " + destino.getAbsolutePath() + "\n");
                JOptionPane.showMessageDialog(this, "Archivo subido correctamente.");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error al subir archivo: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_jButton4ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextArea jTextArea3;
    private javax.swing.JTextArea jTextArea4;
    private javax.swing.JTextArea jTextArea5;
    // End of variables declaration//GEN-END:variables
}
