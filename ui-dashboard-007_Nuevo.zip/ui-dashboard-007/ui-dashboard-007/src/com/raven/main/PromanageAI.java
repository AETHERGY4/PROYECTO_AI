/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raven.main;

/**
 *
 * @author anali
 */

import java.sql.*;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class PromanageAI {

    private Connection conn;

    public PromanageAI(Connection conn) {
        this.conn = conn;
    }

    // Detectar retrasos
    private boolean hayRetraso(int idEquipo) throws SQLException {
        String sql = "SELECT MAX(fecha) as ultima_fecha FROM avances WHERE id_equipo = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idEquipo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Timestamp ts = rs.getTimestamp("ultima_fecha");
                    if (ts == null) {
                        return false;
                    }
                    LocalDateTime ultima = ts.toLocalDateTime();
                    long dias = ChronoUnit.DAYS.between(ultima, LocalDateTime.now());
                    return dias > 7;
                }
            }
        }
        return false;
    }

    // Predecir próxima fecha de avance
    private LocalDateTime predecirProximoAvance(int idEquipo) throws SQLException {
        String sql = "SELECT fecha FROM avances WHERE id_equipo = ? ORDER BY fecha";
        List<LocalDateTime> fechas = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idEquipo);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    fechas.add(rs.getTimestamp("fecha").toLocalDateTime());
                }
            }
        }
        if (fechas.size() < 2) {
            return null;
        }

        long totalDias = 0;
        for (int i = 1; i < fechas.size(); i++) {
            totalDias += ChronoUnit.DAYS.between(fechas.get(i - 1), fechas.get(i));
        }
        long promedio = totalDias / (fechas.size() - 1);
        return fechas.get(fechas.size() - 1).plusDays(promedio);
    }

    // Obtener datos del equipo
    private String obtenerDatosEquipo(int idEquipo) throws SQLException {
        String sql = "SELECT nombre_equipo, responsable, proyecto FROM equipos WHERE id_equipo = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idEquipo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return "Responsable: " + rs.getString("nombre_equipo") + "\n"
                            + "Equipo: " + rs.getString("responsable") + "\n"
                            + "Proyecto: " + rs.getString("proyecto") + "\n\n";
                } else {
                    return "Equipo no encontrado.\n\n";
                }
            }
        }
    }

    // Método para el botón
    public String evaluarTodosLosEquipos() throws SQLException {
        StringBuilder resultado = new StringBuilder();

        // Obtener todos los equipos
        String sqlEquipos = "SELECT id_equipo, nombre_equipo, responsable, proyecto FROM equipos";
        try (PreparedStatement psEquipos = conn.prepareStatement(sqlEquipos); ResultSet rsEquipos = psEquipos.executeQuery()) {

            while (rsEquipos.next()) {
                int idEquipo = rsEquipos.getInt("id_equipo");
                String nombre = rsEquipos.getString("nombre_equipo");
                String responsable = rsEquipos.getString("responsable");
                String proyecto = rsEquipos.getString("proyecto");

                resultado.append("-------------------------------------------------------------------------------\n");
                resultado.append("Responsable: ").append(nombre).append("\n");
                resultado.append("Equipo: ").append(responsable).append("\n");
                resultado.append("Proyecto: ").append(proyecto).append("\n");
                resultado.append("-------------------------------------------------------------------------------\n");
                // Último avance
                String sqlUltimo = "SELECT descripcion, fecha FROM avances WHERE id_equipo = ? ORDER BY fecha DESC LIMIT 1";
                try (PreparedStatement psUltimo = conn.prepareStatement(sqlUltimo)) {
                    psUltimo.setInt(1, idEquipo);
                    try (ResultSet rsUltimo = psUltimo.executeQuery()) {
                        if (rsUltimo.next()) {
                            resultado.append("Último avance: ").append(rsUltimo.getString("descripcion"))
                                    .append(" (").append(rsUltimo.getTimestamp("fecha")).append(")\n");
                        } else {
                            resultado.append("No hay avances registrados.\n");
                        }
                    }
                }

                // Todos los avances
                String sqlTodos = "SELECT descripcion, fecha FROM avances WHERE id_equipo = ? ORDER BY fecha";
                try (PreparedStatement psTodos = conn.prepareStatement(sqlTodos)) {
                    psTodos.setInt(1, idEquipo);
                    try (ResultSet rsTodos = psTodos.executeQuery()) {
                        resultado.append("Todos los avances:\n");
                        boolean tieneAvances = false;
                        while (rsTodos.next()) {
                            tieneAvances = true;
                            resultado.append("- ").append(rsTodos.getString("descripcion"))
                                    .append(" (").append(rsTodos.getTimestamp("fecha")).append(")\n");
                        }
                        if (!tieneAvances) {
                            resultado.append("  Ninguno\n");
                        }
                    }
                }

                // Retraso
                if (hayRetraso(idEquipo)) {
                    resultado.append("⚠️ Este equipo lleva más de 7 días sin subir avances.\n");
                }

                // Próximo avance estimado
                LocalDateTime proximo = predecirProximoAvance(idEquipo);
                if (proximo != null) {
                    resultado.append("📅 Próximo avance estimado: ").append(proximo).append("\n");
                } else {
                    resultado.append("ℹ️ No hay datos suficientes para predecir el próximo avance.\n");
                }

                resultado.append("\n");
            }
        }

        return resultado.toString();
    }
}
