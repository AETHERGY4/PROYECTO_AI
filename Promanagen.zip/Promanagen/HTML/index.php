<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: /Promanagen/HTML/login.html");
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$usuario_correo = $_SESSION['usuario_correo'];

$conn = new mysqli("localhost", "root", "", "promanage");
if ($conn->connect_error) die("Conexión fallida: " . $conn->connect_error);

$stmt = $conn->prepare("SELECT id, nombre, descripcion, ultimo_commit FROM proyectos WHERE usuario_id = ?");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$proyectos = [];
while ($row = $result->fetch_assoc()) $proyectos[] = $row;
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Repositorio de <?php echo htmlspecialchars($usuario_correo); ?></title>
<link rel="stylesheet" href="/Promanagen/CSS/repositorio.css">
</head>
<body>
<header class="header">
    <div class="header-left">
        <h1><?php echo htmlspecialchars($usuario_correo); ?></h1>
        <span>Mis proyectos</span>
    </div>
    <div class="header-right">
        <a href="/Promanagen/HTML/Inicio.html" class="btn">Cerrar sesión</a>
        <a href="/Promanagen/HTML/perfil.php" class="btn">Ver Perfil</a>
    </div>
</header>

<main class="container">
    <div class="dashboard">
        <h2>Dashboard</h2>
        <p>Total de proyectos: <?php echo count($proyectos); ?></p>
    </div>


    <?php if (empty($proyectos)): ?>
        <p>No tienes proyectos todavía.</p>
    <?php else: ?>
        <?php foreach ($proyectos as $proyecto): ?>
        <div class="repositorio">
            <h2><?php echo htmlspecialchars($proyecto['nombre']); ?></h2>
            <p><?php echo htmlspecialchars($proyecto['descripcion']); ?></p>
            <p><strong>Último commit:</strong> <?php echo htmlspecialchars($proyecto['ultimo_commit']); ?></p>
            <div class="repo-actions">
                <a href="ver_proyecto.php?id=<?php echo $proyecto['id']; ?>"><button>Ver Archivos</button></a>
                <a href="editar_proyecto.php?id=<?php echo $proyecto['id']; ?>"><button>Editar</button></a>
                <a href="eliminar_proyecto.php?id=<?php echo $proyecto['id']; ?>"><button>Eliminar</button></a>
            </div>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
    <div class="acciones">
           <a href="/Promanagen/HTML/crear_proyecto.php" class="btn">Crear proyecto</a>
    </div>
</main>
</body>
</html>