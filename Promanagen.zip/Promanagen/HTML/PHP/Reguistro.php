<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "promanage";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
  die("Conexión fallida: " . $conn->connect_error);
}


$correo = isset($_POST['correo']) ? trim($_POST['correo']) : '';
$contrasena = isset($_POST['contrasena']) ? trim($_POST['contrasena']) : '';
$confirmar = isset($_POST['confirmar']) ? trim($_POST['confirmar']) : '';


if (empty($correo) || empty($contrasena) || empty($confirmar)) {
  echo "Por favor, completa todos los campos.";
  exit;
}

if ($contrasena !== $confirmar) {
  header("Location: /Promanagen/HTML/conta_no_con.html");
  echo "Las contraseñas no coinciden.";
  exit;
}


$stmt = $conn->prepare("SELECT id FROM usuarios WHERE correo = ?");
$stmt->bind_param("s", $correo);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
  header("Location: /Promanagen/HTML/correo_ya_regis.html");
  echo "El correo ya está registrado.";
  exit;
}
$stmt->close();


$stmt = $conn->prepare("INSERT INTO usuarios (correo, contrasena) VALUES (?, ?)");
$stmt->bind_param("ss", $correo, $contrasena);

if ($stmt->execute()) {
  
  header("Location: /Promanagen/HTML/Exito.html");
  exit;
} else {
  echo "Error al registrar: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>