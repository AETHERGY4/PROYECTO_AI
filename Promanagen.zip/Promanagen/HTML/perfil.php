<?php
session_start();
if (!isset($_SESSION['usuario_id'])) header("Location: login.html");

$usuario_id = $_SESSION['usuario_id'];
$usuario_correo = $_SESSION['usuario_correo'];

$conn = new mysqli("localhost", "root", "", "promanage");
if ($conn->connect_error) die("Conexión fallida: " . $conn->connect_error);

// Actualizar datos si se envió el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $telefono = $_POST['telefono'];
    $ubicacion = $_POST['ubicacion'];
    $bio = $_POST['bio'];

    $stmt = $conn->prepare("UPDATE usuarios SET nombre=?, telefono=?, ubicacion=?, bio=? WHERE id=?");
    $stmt->bind_param("ssssi", $nombre, $telefono, $ubicacion, $bio, $usuario_id);
    $stmt->execute();
    $stmt->close();
}

// Traer datos actuales
$stmt = $conn->prepare("SELECT nombre, telefono, ubicacion, bio FROM usuarios WHERE id=?");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$usuario = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Perfil de <?php echo htmlspecialchars($usuario_correo); ?></title>
<link rel="stylesheet" href="/Promanagen/CSS/repositorio.css">
</head>
<body>
<header class="header">
    <div class="header-left">
        <h1><?php echo htmlspecialchars($usuario_correo); ?></h1>
        <span>Perfil de Usuario</span>
    </div>
    <div class="header-right">
        <a href="/Promanagen/HTML/index.php" class="btn">Volver</a>
    </div>
</header>

<main class="container">
    <div class="repositorio">
        <h2>Información del Perfil</h2>
        <form method="post">
            <label>Nombre:</label><br>
            <input type="text" name="nombre" value="<?php echo htmlspecialchars($usuario['nombre']); ?>" class="input-field"><br><br>

            <label>Teléfono:</label><br>
            <input type="text" name="telefono" value="<?php echo htmlspecialchars($usuario['telefono']); ?>" class="input-field"><br><br>

            <label>Ubicación:</label><br>
            <input type="text" name="ubicacion" value="<?php echo htmlspecialchars($usuario['ubicacion']); ?>" class="input-field"><br><br>

            <label>Bio:</label><br>
            <textarea name="bio" class="input-field"><?php echo htmlspecialchars($usuario['bio']); ?></textarea><br><br>

            <button type="submit" class="btn">Guardar Cambios</button>
        </form>
    </div>
</main>
</body>
</html>
