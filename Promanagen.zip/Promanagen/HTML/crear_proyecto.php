<?php
session_start();
if (!isset($_SESSION['usuario_id'])) header("Location: login.html");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $usuario_id = $_SESSION['usuario_id'];

    $conn = new mysqli("localhost", "root", "", "promanage");
    $stmt = $conn->prepare("INSERT INTO proyectos (usuario_id, nombre, descripcion) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $usuario_id, $nombre, $descripcion);
    $stmt->execute();
    $stmt->close();
    $conn->close();

    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Crear Proyecto</title>
<link rel="stylesheet" href="/Promanagen/CSS/repositorio.css">
</head>
<body>
<header class="header">
    <div class="header-left">
        <h1><?php echo htmlspecialchars($_SESSION['usuario_correo']); ?></h1>
        <span>Crear proyecto</span>
    </div>
    <div class="header-right">
        <a href="index.php" class="btn">Volver</a>
    </div>
</header>

<main class="container">
    <div class="repositorio">
        <h2>Nuevo Proyecto</h2>
        <form method="post">
            <label>Nombre:</label><br>
            <input type="text" name="nombre" required style="width:100%;padding:8px;margin-bottom:10px;"><br>
            <label>Descripción:</label><br>
            <textarea name="descripcion" style="width:100%;padding:8px;margin-bottom:10px;"></textarea><br>
            <button type="submit" class="btn">Crear Proyecto</button>
        </form>
    </div>
</main>
</body>
</html>